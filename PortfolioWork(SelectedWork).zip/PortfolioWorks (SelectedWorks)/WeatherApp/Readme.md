# TurkWeatherStation Professional weather website showing the weather in Turkey by city, with a contact page. --- ## Project Structure 

TurkWeatherStation/ │ ├─ public/ │ ├─ index.html ← Home page (search city + weather summary) │ ├─ weather.html ← Detailed weather page for each city │ ├─ contact.html ← Contact developer page │ ├─ css/ │ │ └─ style.css ← Additional styles + hover & transition effects │ ├─ js/ │ │ └─ script.js ← Fetching weather data from API and displaying it │ ├─ assets/ │ ├─ icons/ ← Weather icons (sun, cloud, rain, etc.) │ └─ images/ ← Background images according to weather │ ├─ api/ │ └─ weather.js ← API route to fetch weather data │ ├─ package.json ← Project dependencies and scripts └─ README.md ← This file

--- ## Features - Search weather by city in Turkey. - Display summary on the home page. - Detailed weather page per city. - Contact page with developer info. - Beautiful dark-themed design with linear gradient backgrounds. - Bootstrap, Tailwind, FontAwesome for styling. - Hover and transition effects for buttons and cards. - Modular API route for fetching weather data. --- ## Installation & Running Locally 1. **Clone the repository**: ```bash git clone <repository_url> cd TurkWeatherStation 

Install dependencies:

npm install 

Run locally using Vercel CLI:

npm run dev 

Open your browser at http://localhost:3000.

Deployment

The project can be deployed on Vercel.

Static pages + API route are supported.

Make sure your Node version is >= 18.

Developer Contact

GitHub: https://github.com/EnverHakimoglu

Phone: 01552162595

Email: EnverHakimdaroğlu@gmail.com

Instagram: https://www.instagram.com/enverhakimdaro

Facebook: https://www.facebook.com/share/176A7ac58y/

LinkedIn: https://eg.linkedin.com/in/enver-hakimdaroğlu-b2907a376

Portfolio: https://shihabubashiportfolio.netlify.app/