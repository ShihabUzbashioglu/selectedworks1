// api/weather.js
import fetch from "node-fetch";

export default async function handler(req, res) {
    // التأكد من وجود استعلام المدينة
    const { city } = req.query;
    if (!city) {
        return res.status(400).json({ error: "City parameter is required" });
    }

    try {
        const API_KEY = process.env.OPENWEATHER_API_KEY; // ضع مفتاحك في إعدادات Vercel Environment Variables
        const BASE_URL = "https://api.openweathermap.org/data/2.5/weather";

        const response = await fetch(`${BASE_URL}?q=${city},TR&units=metric&appid=${API_KEY}`);
        if (!response.ok) throw new Error("City not found");

        const data = await response.json();

        // يمكنك تعديل البيانات هنا إذا أحببت
        const weatherData = {
            city: data.name,
            country: data.sys.country,
            temperature: data.main.temp,
            humidity: data.main.humidity,
            windSpeed: data.wind.speed,
            weatherMain: data.weather[0].main,
            weatherDescription: data.weather[0].description,
            icon: data.weather[0].icon
        };

        res.status(200).json(weatherData);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
}