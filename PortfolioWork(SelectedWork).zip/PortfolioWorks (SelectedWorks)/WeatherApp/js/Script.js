// Script.js for TurkWeather Station

// ============================
// Constants and DOM Elements
// ============================
const searchForm = document.getElementById("search-form");
const cityInput = document.getElementById("city-input");
const weatherContainer = document.getElementById("weather-container");
const API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"; // ضع مفتاحك هنا
const BASE_URL = "https://api.openweathermap.org/data/2.5/weather";

// ============================
// Fetch Weather Data
// ============================
async function getWeather(city) {
    try {
        const response = await fetch(`${BASE_URL}?q=${city},TR&units=metric&appid=${API_KEY}`);
        if (!response.ok) throw new Error("City not found!");
        const data = await response.json();
        displayWeather(data);
    } catch (error) {
        console.error(error);
        weatherContainer.innerHTML = `<p class="text-danger text-center">Error: ${error.message}</p>`;
    }
}

// ============================
// Display Weather Data
// ============================
function displayWeather(data) {
    const { name, main, weather, wind } = data;
    const iconUrl = `https://openweathermap.org/img/wn/${weather[0].icon}@2x.png`;

    // Dynamic background based on weather
    let bgClass = "bg-default";
    if (weather[0].main === "Clear") bgClass = "bg-sunny";
    else if (weather[0].main === "Clouds") bgClass = "bg-cloudy";
    else if (weather[0].main === "Rain" || weather[0].main === "Drizzle") bgClass = "bg-rainy";
    else if (weather[0].main === "Snow") bgClass = "bg-snow";

    weatherContainer.innerHTML = `
        <div class="card weather-card ${bgClass}">
            <h2>${name}, Turkey</h2>
            <img src="${iconUrl}" alt="${weather[0].description}">
            <p><strong>${weather[0].main}</strong> - ${weather[0].description}</p>
            <p>Temperature: ${main.temp}°C</p>
            <p>Humidity: ${main.humidity}%</p>
            <p>Wind Speed: ${wind.speed} m/s</p>
        </div>
    `;
}

// ============================
// Handle Search Form
// ============================
searchForm.addEventListener("submit", function(e) {
    e.preventDefault();
    const city = cityInput.value.trim();
    if (city) {
        getWeather(city);
        cityInput.value = "";
    }
});

// ============================
// Optional: Load default city
// ============================
window.addEventListener("DOMContentLoaded", () => {
    getWeather("Istanbul"); // عرض الطقس الافتراضي عند تحميل الصفحة
});