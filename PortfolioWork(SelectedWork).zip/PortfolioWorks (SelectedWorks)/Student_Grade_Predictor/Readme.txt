# StudentGradePredictor

A professional project for predicting student final grades using Machine Learning and Deep Learning techniques.

## Project Structure

StudentGradePredictor/ ├── data/               # Dataset folder │   └── student_data.csv ├── notebooks/          # Data exploration and analysis │   └── data_analysis.ipynb ├── scripts/            # Training and prediction scripts │   ├── train_model.py │   └── predict_grade.py ├── models/             # Saved trained models │   └── student_grade_model.h5 ├── utils/              # Helper functions for data preprocessing │   └── data_processing.py ├── requirements.txt └── README.md

## Project Overview

This project predicts student final grades based on features such as:
- Attendance
- Homework scores
- Midterm scores
- Study hours
- Participation

The project uses:
- Neural Networks with TensorFlow/Keras
- Data preprocessing with Pandas and Scikit-Learn
- Visualization with Matplotlib and Seaborn

## Setup

1. Clone the repository:

```bash
git clone <repository-url>
cd StudentGradePredictor

2. Install required packages:



pip install -r requirements.txt

3. Prepare your dataset in data/student_data.csv.
Optionally, create data/new_student_data.csv for prediction tests.



Usage

1. Data Analysis

Open notebooks/data_analysis.ipynb to explore and visualize the dataset.

2. Train the Model

python scripts/train_model.py

The model will be saved to models/student_grade_model.h5.


3. Predict Grades

python scripts/predict_grade.py

The script predicts final grades for new students.

Results are displayed and saved to data/predicted_grades.csv.


Features

Clean and modular code with clear English comments

Data preprocessing and normalization

Neural network regression model

Training history visualization (Loss and MAE)

Prediction for new student data


License

This project is open-source and free to use.