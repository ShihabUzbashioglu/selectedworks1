// ===========================
// Smooth Scroll for anchor links
// ===========================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if(target){
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// ===========================
// Back to Top Button
// ===========================
const backToTopBtn = document.createElement('button');
backToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
backToTopBtn.className = 'fixed bottom-8 right-8 bg-blue-500 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition hidden';
document.body.appendChild(backToTopBtn);

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

window.addEventListener('scroll', () => {
    if(window.scrollY > 300){
        backToTopBtn.classList.remove('hidden');
    } else {
        backToTopBtn.classList.add('hidden');
    }
});

// ===========================
// Lightbox for Images (Designs page)
// ===========================
const images = document.querySelectorAll('.gallery img');
if(images.length > 0){
    const lightbox = document.createElement('div');
    lightbox.id = 'lightbox';
    lightbox.style.cssText = `
        position: fixed;
        top:0; left:0; width:100%; height:100%;
        background: rgba(0,0,0,0.8);
        display: flex; justify-content:center; align-items:center;
        visibility: hidden; opacity:0; transition: opacity 0.3s;
        z-index:1000;
    `;
    const imgElement = document.createElement('img');
    imgElement.style.maxWidth = '90%';
    imgElement.style.maxHeight = '90%';
    lightbox.appendChild(imgElement);
    document.body.appendChild(lightbox);

    images.forEach(img => {
        img.addEventListener('click', () => {
            imgElement.src = img.src;
            lightbox.style.visibility = 'visible';
            lightbox.style.opacity = '1';
        });
    });

    lightbox.addEventListener('click', () => {
        lightbox.style.opacity = '0';
        setTimeout(() => lightbox.style.visibility = 'hidden', 300);
    });
}

// ===========================
// Navbar collapse toggle (Bootstrap handled, optional enhancement)
// ===========================
const navbarToggler = document.querySelector('.navbar-toggler');
const navbarCollapse = document.querySelector('#navbarNav');

if(navbarToggler && navbarCollapse){
    navbarToggler.addEventListener('click', () => {
        navbarCollapse.classList.toggle('show');
    });
}

// ===========================
// Optional: smooth hover scale for cards
// ===========================
document.querySelectorAll('.hover-scale').forEach(card => {
    card.addEventListener('mouseenter', () => {
        card.style.transform = 'scale(1.05)';
        card.style.transition = 'transform 0.3s ease';
    });
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'scale(1)';
    });
});