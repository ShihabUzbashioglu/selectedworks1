// تسجيل الدخول
function checkLogin() {
  const username = document.getElementById("adminUsername").value;
  const loginError = document.getElementById("loginError");

  if (username === "Uzbashi Çok123") {
    document.getElementById("loginSection").classList.add("hidden");
    document.getElementById("adminPanel").classList.remove("hidden");
  } else {
    loginError.textContent = "❌ Wrong Username!";
  }
}

// حفظ المقالة في LocalStorage
document.getElementById("articleForm")?.addEventListener("submit", function (e) {
  e.preventDefault();

  const title = document.getElementById("articleTitle").value;
  const summary = document.getElementById("articleSummary").value;
  const content = document.getElementById("articleContent").value;

  let articles = JSON.parse(localStorage.getItem("articles")) || [];

  articles.push({
    id: Date.now(),
    title,
    summary,
    content
  });

  localStorage.setItem("articles", JSON.stringify(articles));

  document.getElementById("articleForm").reset();
  document.getElementById("successMsg").classList.remove("d-none");

  setTimeout(() => {
    document.getElementById("successMsg").classList.add("d-none");
  }, 2000);
});