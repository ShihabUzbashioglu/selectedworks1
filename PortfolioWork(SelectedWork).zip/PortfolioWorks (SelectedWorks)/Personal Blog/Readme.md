# 📝 Personal Blog - Static Website A modern **personal blogging platform** built with **HTML, CSS (Bootstrap + Tailwind), and JavaScript**. This project is designed for deployment on **Vercel** (static hosting). It allows the admin to **add, manage, and display blog articles** dynamically using **LocalStorage** without a backend. --- ## 🚀 Features - **Home Page (index.html)** Beautiful Hero section with introduction and navigation. - **Articles Page (articles.html)** Displays all blog posts in elegant cards with title & excerpt. - **Single Article Page (article.html)** Opens a full blog post when clicked from the articles list. - **Contact Page (contact.html)** Includes links and details to connect with the developer. - **Admin Page (admin.html)** - Login system (username + password). - Add new articles with **title, excerpt, and content**. - Articles are saved in **LocalStorage** and displayed automatically. --- ## 🔐 Admin Login - **Username:** `Uzbashi` - **Password:** `Çok123` --- ## 🛠️ Technologies Used - **HTML5** - **CSS3** - Bootstrap (CDN) - Tailwind CSS (CDN) - Custom CSS (`css/style.css`) - **JavaScript (Vanilla)** → (`js/script.js`) - **LocalStorage** for persisting blog posts - **Font Awesome (CDN)** for icons --- ## 📂 Project Structure 

PersonalBlog/ │ ├── index.html # Home page (Hero + Sections + Links) ├── articles.html # Articles list (Cards) ├── article.html # Single article page ├── contact.html # Contact page ├── admin.html # Admin login + Add articles │ ├── css/ │ └── style.css # Custom styles │ ├── js/ │ └── script.js # Blog logic (Login + Articles + LocalStorage) │ └── assets/ ├── img/ # Images (logo, article images...) └── icons/ # Additional icons

--- ## 📸 Screenshots (Optional) _Add some screenshots of your blog UI here (Home, Articles, Admin panel)._ --- ## ⚡ Getting Started 1. Clone the repo: ```bash git clone https://github.com/EnverHakimoglu/PersonalBlog.git cd PersonalBlog 

Open index.html in your browser.
Or use Live Server (VS Code extension).

To add articles:

Go to admin.html

Enter credentials (see above).

Add your new post.

🌐 Deployment on Vercel

Push the project to your GitHub repository.

Go to Vercel.

Import your GitHub repo.

Deploy → Your blog is live! 🎉

👨‍💻 Developer Info

GitHub: EnverHakimoglu

Portfolio: Portfolio Website

Email: EnverHakimdaroglu@gmail.com

Phone: 01552162595

Instagram: enverhakimdar

Facebook: Facebook Profile

LinkedIn: LinkedIn Profile