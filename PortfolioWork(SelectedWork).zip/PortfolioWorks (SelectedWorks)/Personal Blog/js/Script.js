// ============================
// LocalStorage Utils
// ============================
function getArticles() {
  return JSON.parse(localStorage.getItem("articles")) || [];
}

function saveArticles(articles) {
  localStorage.setItem("articles", JSON.stringify(articles));
}

// ============================
// Admin Login
// ============================
function loginAdmin() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const loginMessage = document.getElementById("loginMessage");

  if (username === "Uzbashi" && password === "Çok123") {
    localStorage.setItem("isAdmin", "true");
    window.location.href = "admin.html";
  } else {
    loginMessage.textContent = "❌ Wrong credentials!";
  }
}

// ============================
// Add Article (Admin Only)
// ============================
function addArticle(event) {
  event.preventDefault();

  const title = document.getElementById("articleTitleInput").value.trim();
  const excerpt = document.getElementById("articleExcerptInput").value.trim();
  const content = document.getElementById("articleContentInput").value.trim();

  if (!title || !excerpt || !content) {
    alert("⚠️ Please fill all fields!");
    return;
  }

  const articles = getArticles();
  const newArticle = {
    id: Date.now(),
    title,
    excerpt,
    content
  };

  articles.push(newArticle);
  saveArticles(articles);

  document.getElementById("adminForm").reset();
  alert("✅ Article added successfully!");
  loadArticles(); // refresh list
}

// ============================
// Load Articles in articles.html
// ============================
function loadArticles() {
  const articles = getArticles();
  const container = document.getElementById("articlesContainer");

  if (!container) return;

  if (articles.length === 0) {
    container.innerHTML = "<p class='text-center text-muted'>No articles yet.</p>";
    return;
  }

  container.innerHTML = "";
  articles.forEach(article => {
    const card = `
      <div class="col-md-4 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">${article.title}</h5>
            <p class="card-text">${article.excerpt}</p>
            <a href="article.html?id=${article.id}" class="btn btn-primary">
              Read More
            </a>
          </div>
        </div>
      </div>
    `;
    container.innerHTML += card;
  });
}

// ============================
// Load Single Article in article.html
// ============================
function loadArticle() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  if (!id) return;

  const articles = getArticles();
  const article = articles.find(a => a.id == id);

  if (article) {
    document.getElementById("articleTitle").textContent = article.title;
    document.getElementById("articleContent").textContent = article.content;
  } else {
    document.getElementById("articleContainer").innerHTML =
      "<p class='text-danger'>❌ Article not found.</p>";
  }
}

// ============================
// Auto-run depending on page
// ============================
document.addEventListener("DOMContentLoaded", () => {
  const path = window.location.pathname;

  if (path.includes("articles.html")) {
    loadArticles();
  }

  if (path.includes("article.html")) {
    loadArticle();
  }

  if (path.includes("admin.html")) {
    const isAdmin = localStorage.getItem("isAdmin");

    // لو لسه مش مسجل دخول → يظهر فورم تسجيل الدخول
    if (isAdmin !== "true") {
      document.getElementById("loginSection").style.display = "block";
      document.getElementById("adminSection").style.display = "none";

      document.getElementById("loginForm").addEventListener("submit", e => {
        e.preventDefault();
        loginAdmin();
      });
    } else {
      document.getElementById("loginSection").style.display = "none";
      document.getElementById("adminSection").style.display = "block";

      document.getElementById("adminForm").addEventListener("submit", addArticle);
      loadArticles();
    }
  }
});