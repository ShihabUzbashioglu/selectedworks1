// عرض المقال في article.html
function loadArticle() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) return;

  const articles = JSON.parse(localStorage.getItem("articles")) || [];
  const article = articles.find(a => a.id == id);

  if (article) {
    document.getElementById("articleTitle").textContent = article.title;
    document.getElementById("articleContent").textContent = article.content;
  } else {
    document.getElementById("articleContainer").innerHTML = "<p class='text-danger'>❌ Article not found.</p>";
  }
}

// شغّل الوظيفة لو انت في article.html
if (window.location.pathname.includes("article.html")) {
  loadArticle();
}