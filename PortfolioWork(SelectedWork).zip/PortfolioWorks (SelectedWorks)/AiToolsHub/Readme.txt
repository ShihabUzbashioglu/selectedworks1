AiToolsHub

AiToolsHub is an interactive web project built with Flask and Python, offering a collection of ready-to-use AI tools. The project features an elegant interface powered by Bootstrap5, Tailwind, and FontAwesome CDN, allowing users to access tools like background removal, face detection, OCR, language detection, and movie recommendations.

🛠️ Available Tools

Background Remove

Automatically removes the background from images.

Face Detection

Detects all faces in images and highlights them with bounding boxes.

OCR (Optical Character Recognition)

Converts written text in images into editable digital text.

Language Detection

Detects the language of any written or pasted text.

Movie Recommender

Suggests top movies based on star ratings and preferences.

📂 Project Structure

AiToolsHub/ │ ├─ app.py ← Main Flask server ├─ requirements.txt ← Python dependencies ├─ templates/ ← HTML templates │ ├─ index.html ← Home page with Hero + Tools │ ├─ background_remove.html │ ├─ face_detection.html │ ├─ ocr.html │ ├─ language_detection.html │ ├─ movie_recommender.html │ └─ layout.html ← Base template shared by all pages ├─ static/ │ ├─ css/ │ │ └─ style.css ← Custom styles │ ├─ js/ │ │ └─ scripts.js ← Interactive scripts │ └─ images/ │ └─ placeholder.jpg └─ README.md 

🚀 Installation

Clone the repository

git clone https://github.com/yourusername/AiToolsHub.git cd AiToolsHub 

Create a virtual environment (optional but recommended)

python -m venv venv source venv/bin/activate # Linux/Mac venv\Scripts\activate # Windows 

Install dependencies

pip install -r requirements.txt 

🖥️ Running the Project

python app.py 

Open your browser and go to: http://127.0.0.1:5000/

Access all AI tools from the home page.

✨ Features

Responsive and modern UI using Bootstrap5 and Tailwind.

Interactive forms and real-time feedback with JavaScript.

Easily extendable to add more AI tools.

Each tool has its own dedicated page with clear instructions.

⚡ Future Improvements

Add more AI tools like image colorization, text summarization, and sentiment analysis.

Add user authentication to save history and preferences.

Deploy online for global access.