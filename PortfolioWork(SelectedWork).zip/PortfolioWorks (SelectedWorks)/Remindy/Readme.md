# Remindy **Remindy** is a modern, interactive, and visually appealing To-Do List application inspired by Notion. It is built using **Bootstrap**, **TailwindCSS**, and **FontAwesome**, designed to help users manage tasks efficiently and beautifully. --- ## Features - **Add, edit, and delete tasks** with ease. - **Mark tasks as completed** with visual feedback. - **Persistent tasks** using LocalStorage. - **Interactive task cards** with hover effects, scaling, and transitions. - **Responsive design** for desktop and mobile. - Optional **icons and visual enhancements**. --- ## Project Structure 

Remindy/ │ ├─ public/ │ ├─ index.html ← Main app page (Task Board) │ ├─ css/ │ │ └─ style.css ← Custom styles + hover & transition effects │ ├─ js/ │ │ └─ script.js ← Task management and interactivity │ ├─ assets/ │ └─ icons/ ← Optional icons │ ├─ package.json ← For managing dependencies locally └─ README.md

--- ## Getting Started 1. **Clone the repository:** ```bash git clone <your-repo-url> 

Install dependencies (optional, for Tailwind CLI or live-server):

npm install 

Run the project locally:

npm run start 

This will open the app in your default browser using live-server.

Build Tailwind CSS (if needed):

npm run build-css 

Usage

Type a task in the input field and press Add or Enter.

Click the check icon to mark it as completed.

Click the edit icon to change the title or description.

Click the trash icon to delete a task.

Tasks are automatically saved and restored using LocalStorage.

Developer

Enver Hakimdaroğlu

Portfolio: shihabubashiportfolio.netlify.app

GitHub: EnverHakimoglu

LinkedIn: Enver Hakimdaroğlu

Instagram: @enverhakimdaro

License

This project is licensed under the MIT License.