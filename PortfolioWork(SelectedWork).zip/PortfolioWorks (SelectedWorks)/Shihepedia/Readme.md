# Shihepedia **Shihepedia** is a modern, interactive knowledge hub and multimedia platform designed to provide in-depth articles, videos, creative works, and dynamic explorations. It’s built with **Tailwind CSS**, **Bootstrap 5**, and **FontAwesome**, ensuring a responsive, visually appealing experience across all devices. --- ## Table of Contents - [About](#about) - [Features](#features) - [Pages](#pages) - [Technologies](#technologies) - [Setup & Usage](#setup--usage) - [Developer Contact](#developer-contact) - [License](#license) --- ## About Shihepedia is designed as an educational and creative platform combining: - **Articles & Wiki Entries:** Insightful content on a variety of topics. - **Video Tutorials:** Interactive video-based learning. - **Creative Designs:** Showcase of multimedia works and projects. - **Explore Section:** Dynamic content fetched from external APIs to discover topics and locations visually. - **Advanced Search:** Easily find content across all sections. This project is responsive, interactive, and designed for modern web standards. It is suitable as a personal portfolio, educational hub, or knowledge-sharing platform. --- ## Features - Fully **responsive layout** optimized for desktops, tablets, and mobile screens. - Dynamic **hero section animations**. - **API-powered Explore section** for interactive content discovery. - Advanced **search functionality** across articles, videos, and designs. - Smooth **scrolling and hover animations**. - Integration with **FontAwesome icons** for modern visual appeal. - Clean, professional UI combining **Tailwind CSS** and **Bootstrap 5**. --- ## Pages | Page | Description | |------|-------------| | `index.html` | Home page with Hero, Overview, and Highlights | | `about.html` | About Shihepedia / Developer info | | `articles.html` | Articles / Wiki Entries | | `videos.html` | Video Tutorials | | `designs.html` | Creative Works & Multimedia | | `explore.html` | Explore Topics dynamically via API | | `contact.html` | Contact Developer & Social Links | | `search.html` | Advanced Search page | --- ## Technologies - **HTML5 & CSS3** - **JavaScript (ES6)** - **Bootstrap 5** - **Tailwind CSS** - **FontAwesome** - **Fetch API for dynamic content** - Responsive design and interactive UI elements --- ## Setup & Usage 1. Clone this repository: ```bash git clone https://github.com/YourUsername/Shihepedia.git 

Open the project folder in your preferred code editor.

Open index.html in your browser to explore the platform.

Ensure internet connection for CDN resources (Bootstrap, Tailwind, FontAwesome) and API content.

Developer Contact

Name: Enver Hakimdaroglu

Email: EnverHakimdaroglu@gmail.com

Phone: +20 1552162595

GitHub: https://github.com/EnverHakimoglu

Portfolio: https://enverhakimdarogluportfolio1.netlify.app/

Blog: https://enverblog.netlify.app/

Instagram: https://www.instagram.com/enverhakimdar

LinkedIn: https://eg.linkedin.com/in/enver-hakimdaro%C4%9Flu-b2907a376

Facebook: https://www.facebook.com/share/176A7ac58y/

License

This project is free to use, modify, and distribute for personal or educational purposes. For commercial use, please contact the developer.

This project was created as a professional portfolio and knowledge-sharing platform by Enver Hakimdaroglu.