/* ===================================
   Shihepedia main.js
   Interactions + API Fetch + Search
=================================== */

/* -----------------------------
   Navbar Active Link Highlight
----------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  const currentPage = location.pathname.split("/").pop();
  const navLinks = document.querySelectorAll(".nav-link");

  navLinks.forEach(link => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active");
    }
  });
});

/* -----------------------------
   Hero Scroll Animation
----------------------------- */
const heroText = document.querySelector(".hero-text");
window.addEventListener("scroll", () => {
  if (heroText) {
    heroText.style.transform = `translateY(${window.scrollY * 0.3}px)`;
    heroText.style.opacity = 1 - window.scrollY / 600;
  }
});

/* -----------------------------
   Explore Turkey API Fetch
   (example with placeholder API)
----------------------------- */
const exploreContainer = document.querySelector("#explore-container");
if (exploreContainer) {
  fetch("https://api.example.com/turkey-places") // Replace with real API
    .then(response => response.json())
    .then(data => {
      exploreContainer.innerHTML = data.map(place => `
        <div class="col-md-4 mb-4">
          <div class="card explore-card">
            <img src="${place.image}" class="card-img-top" alt="${place.name}">
            <div class="card-body">
              <h5 class="card-title">${place.name}</h5>
              <p class="card-text">${place.description}</p>
            </div>
          </div>
        </div>
      `).join("");
    })
    .catch(error => {
      exploreContainer.innerHTML = `<p class="text-danger">Failed to load Turkey places. Please try again later.</p>`;
      console.error(error);
    });
}

/* -----------------------------
   Search Functionality
----------------------------- */
const searchInput = document.querySelector("#search-input");
const searchResultsContainer = document.querySelector("#search-results");

if (searchInput && searchResultsContainer) {
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    const items = searchResultsContainer.querySelectorAll(".search-item");

    items.forEach(item => {
      const title = item.querySelector(".search-title").textContent.toLowerCase();
      const content = item.querySelector(".search-content").textContent.toLowerCase();
      if (title.includes(query) || content.includes(query)) {
        item.style.display = "";
      } else {
        item.style.display = "none";
      }
    });
  });
}

/* -----------------------------
   Card Hover Animations
----------------------------- */
const cards = document.querySelectorAll(".card");
cards.forEach(card => {
  card.addEventListener("mouseenter", () => {
    card.classList.add("shadow-lg");
    card.style.transform = "translateY(-5px)";
  });
  card.addEventListener("mouseleave", () => {
    card.classList.remove("shadow-lg");
    card.style.transform = "translateY(0)";
  });
});

/* -----------------------------
   Smooth Scroll for Anchor Links
----------------------------- */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});