# UnitTestedCalculator

A clean, production-quality Python calculator library built *to showcase Unit Testing* best practices using **pytest**, **pytest-cov**, and **Hypothesis** (property-based testing).

## Why this project?
- Clear separation of **pure functions** and a small **OOP facade**.
- Tests demonstrate **basic**, **edge-case**, and **property-based** approaches.
- Ready-to-run coverage and pytest config via `pyproject.toml`.

## Project Structure

UnitTestedCalculator/ ├─ src/calculator/ │  ├─ init.py │  └─ calc.py ├─ tests/ │  ├─ test_calc_basic.py │  ├─ test_calc_edge_cases.py │  └─ test_calc_property.py ├─ pyproject.toml ├─ requirements.txt └─ README.md

## Quick Start

```bash
# 1) Create venv (optional but recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run tests
pytest

# With coverage:
pytest --cov=calculator --cov-report=term-missing

What to look at

tests/test_calc_basic.py: happy-path unit tests.

tests/test_calc_edge_cases.py: exceptions, invalid domains, parametrized tests.

tests/test_calc_property.py: algebraic properties (commutativity, inverses).


Extending the library

Add parsing of expressions (e.g., "3 + 4 * 2").

Add trig functions (sin, cos, tan) with radians/degree toggles.

Add a CLI: python -m calculator "2+2".


Notes

Functions raise clear exceptions: ZeroDivisionError, ValueError, TypeError.

Property-based tests help reveal hidden edge cases that example-based tests miss.