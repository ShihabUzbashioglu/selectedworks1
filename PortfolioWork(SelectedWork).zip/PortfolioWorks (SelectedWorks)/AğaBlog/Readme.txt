# AğaBlog AğaBlog is a scientific and technical articles website divided into multiple sections such as Physics, History, Technology, Engineering, and Biology. The website uses **Node.js + Express** as a server and displays content stored in text files inside the **Assets** folder. --- ## Project Structure 

AğaBlog/ │ ├─ public/ │ ├─ index.html ← Main page (Hero + Most Popular Articles) │ ├─ sections/ ← Pages for each category │ │ ├─ physics.html │ │ ├─ history.html │ │ ├─ technology.html │ │ ├─ engineering.html │ │ ├─ biology.html │ │ │ ├─ css/ │ │ └─ style.css ← Additional styles + hover effects │ └─ js/ │ └─ script.js ← Fetch articles from the server and display them │ ├─ Assets/ │ ├─ Physics/ │ │ ├─ Quantum_Entanglement.txt │ │ └─ Relativity.txt │ ├─ History/ │ │ └─ Ancient_Egypt.txt │ ├─ Technology/ │ │ └─ AI_Revolution.txt │ ├─ Engineering/ │ │ └─ Bridge_Design.txt │ └─ Biology/ │ └─ DNA_Secrets.txt │ ├─ server.js ← Node.js server that reads articles and returns them as JSON ├─ package.json └─ README.md

--- ## How to Run ### 1. Install dependencies ```bash npm install 

2. Start normally

npm start 

3. Start in development mode (with auto restart)

npm run dev 

Features

Simple and fast HTML interface

Categorized articles by topic

Dynamic content fetching from the server

Responsive design