تمام، إليك ملف README.md مرتب وواضح لمشروع MyBlog:

# MyBlog A personal blog website built using **HTML**, **CSS (Bootstrap + Tailwind + custom styles)**, and **JavaScript**, with **Vercel API Routes** for serving articles. ## 📌 Features - **Hero Section** on the homepage introducing the blog and developer. - **Articles Page** displaying article summaries as beautiful cards. Clicking a card opens the full article. - **Contact Page** with social links and contact details. - **Responsive Design** using **Bootstrap** and **Tailwind** via CDN. - **Smooth Animations** (hover effects, transitions, scaling). - **Articles stored as `.txt` files** in `Assets/articles` and loaded dynamically via API. --- ## 📂 Project Structure 

MyBlog/ │ ├─ public/ │ ├─ index.html # Homepage (Hero + popular articles) │ ├─ articles.html # Articles list page │ ├─ contact.html # Contact page │ ├─ css/ │ │ └─ style.css # Extra styling & effects │ ├─ js/ │ │ └─ script.js # Fetch and display articles │ ├─ Assets/ │ └─ articles/ # Article text files │ ├─ My_first.txt │ ├─ Tech_Innovation.txt │ └─ Science_Discovery.txt │ ├─ api/ │ └─ articles.js # API route for fetching articles │ ├─ package.json └─ README.md

--- ## 🚀 Getting Started ### 1️⃣ Clone the repository ```bash git clone https://github.com/YourUsername/MyBlog.git cd MyBlog 

2️⃣ Install Vercel CLI (if not installed)

npm install -g vercel 

3️⃣ Run locally

vercel dev 

Your site will be available at http://localhost:3000.

4️⃣ Deploy to Vercel

vercel 

📄 Adding New Articles

Create a new .txt file inside Assets/articles/.

The filename will be used as the article title (underscores _ will be replaced with spaces).

The first few lines will be used as a summary for the Articles Page.

Example:

Assets/articles/New_Discovery.txt 

📞 Contact

Developer: Enver Hakimdaroğlu
GitHub: https://github.com/EnverHakimoglu
Email: EnverHakimdaroglu@gmail.com
Phone: 01552162595