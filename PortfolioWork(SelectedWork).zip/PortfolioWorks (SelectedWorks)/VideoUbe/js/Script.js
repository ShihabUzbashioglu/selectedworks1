// ===========================
// Video Modal & Explore Page
// ===========================
document.addEventListener("DOMContentLoaded", function() {
    const videoCards = document.querySelectorAll('#videoGrid .card');
    const modalElement = document.getElementById('videoModal');
    const modalVideo = document.getElementById('modalVideo');
    const modalTitle = document.getElementById('videoModalLabel');

    if (videoCards.length && modalElement) {
        const videoModal = new bootstrap.Modal(modalElement);

        videoCards.forEach(card => {
            card.addEventListener('click', () => {
                modalVideo.src = card.getAttribute('data-src');
                modalTitle.textContent = card.getAttribute('data-title');
                videoModal.show();
            });
        });

        // Stop video when modal is closed
        modalElement.addEventListener('hidden.bs.modal', () => {
            modalVideo.pause();
            modalVideo.currentTime = 0;
        });
    }

    // ===========================
    // Search Filter
    // ===========================
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const filter = searchInput.value.toLowerCase();
            videoCards.forEach(card => {
                const title = card.getAttribute('data-title').toLowerCase();
                card.parentElement.style.display = title.includes(filter) ? '' : 'none';
            });
        });
    }

    // ===========================
    // Dark Mode Toggle
    // ===========================
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            if(document.body.classList.contains('dark-mode')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
        }
    }

    // ===========================
    // Smooth Scroll for Navbar Links
    // ===========================
    const navLinks = document.querySelectorAll('.navbar .nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if(this.hash !== "") {
                e.preventDefault();
                const hash = this.hash;
                const target = document.querySelector(hash);
                if(target) {
                    window.scrollTo({
                        top: target.offsetTop - 70,
                        behavior: "smooth"
                    });
                }
            }
        });
    });

    // ===========================
    // Optional: Animated Scroll on Load
    // ===========================
    window.addEventListener('load', () => {
        const hero = document.getElementById('hero');
        if(hero) {
            hero.classList.add('animate-fadeIn');
        }
    });
});