# CatDogClassifier

A deep learning project to classify images as either cats or dogs using Convolutional Neural Networks (CNN) with TensorFlow/Keras.

## Project Structure

CatDogClassifier/ ├── data/             # Dataset folder │   ├── train/ │   │   ├── cats/ │   │   └── dogs/ │   ├── validation/ │   │   ├── cats/ │   │   └── dogs/ ├── models/           # Saved trained models ├── scripts/ │   └── train_model.py ├── utils/ │   └── data_loader.py ├── requirements.txt └── README.md

## Setup

1. Install required packages:

```bash
pip install -r requirements.txt

2. Prepare your dataset in the data/ folder (train & validation).


3. Run training:



python scripts/train_model.py

4. The trained model will be saved in models/cat_dog_model.h5.



Features

Data augmentation to improve model generalization.

Early stopping to prevent overfitting.

Clean and modular code structure.

Training & validation accuracy/loss visualization.


---