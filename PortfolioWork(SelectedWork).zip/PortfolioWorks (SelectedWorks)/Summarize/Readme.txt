# SmartTextSummarizer

A professional project for summarizing long texts and articles using state-of-the-art NLP models.

## Project Structure

SmartTextSummarizer/ ├── data/                   # Sample text files │   └── example.txt ├── scripts/ │   ├── summarizer.py       # Text summarization module │   └── app.py              # Streamlit user interface ├── requirements.txt └── README.md

## Project Overview

SmartTextSummarizer allows users to:
- Paste long text or upload text files.
- Generate concise summaries using pre-trained NLP models (e.g., BART, T5).
- Adjust summary length according to user preference.
- Save summaries to a file for later use.

## Features

- Summarize long articles, research papers, or plain text.
- User-friendly Streamlit interface.
- Adjustable summary length (`max_length` and `min_length`).
- Save summaries directly to TXT files.
- Modular code structure for easy maintenance and extension.

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd SmartTextSummarizer

2. Install required packages:



pip install -r requirements.txt

3. Run the Streamlit app:



streamlit run scripts/app.py

Usage

Paste text in the text area or upload a TXT file.

Adjust the summary length via sidebar sliders.

Click "Generate Summary" to view the summary.

Optionally, save the summary to a file.


License

This project is open-source and free to use.