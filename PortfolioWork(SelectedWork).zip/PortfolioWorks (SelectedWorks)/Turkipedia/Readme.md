# Turkipedia 🌐 **Turkipedia** is a modern, responsive, and interactive web platform dedicated to exploring Turkish culture, history, and creativity. This project is designed with a professional layout, intuitive navigation, and enhanced user experience, making it a perfect showcase for articles, videos, designs, and more. --- ## Table of Contents - [Project Overview](#project-overview) - [Features](#features) - [Pages](#pages) - [Technologies Used](#technologies-used) - [Installation](#installation) - [Usage](#usage) - [Developer Contact](#developer-contact) - [License](#license) --- ## Project Overview Turkipedia aims to provide a rich and engaging platform for users who want to learn about Turkey's culture, history, and landmarks. It includes articles, tutorials, creative works, and a unique “Explore Turkey” section powered by a dynamic API fetching Turkish destinations with images and descriptions. This project is designed to be fully responsive, ensuring an optimal viewing experience on desktops, tablets, and mobile devices. --- ## Features - Responsive layout for all devices (Desktop / Tablet / Mobile) - Hero sections with high-quality imagery - Interactive cards with hover animations - Articles / Blog section - Videos / Tutorials section - Creative Designs portfolio - Explore Turkey section (API powered gallery) - Contact form with instant feedback - Smooth scrolling navigation - Lazy loading images for performance - Integrated with **Bootstrap 5**, **Tailwind CSS**, and **FontAwesome** --- ## Pages 1. **Home (`index.html`)** Hero section + overview of all website sections. 2. **About Me / About Turkipedia (`about.html`)** Introduction to the project, its purpose, and background information. 3. **Articles / Blog (`articles.html`)** Collection of articles and blog posts related to Turkey. 4. **Videos / Tutorials (`videos.html`)** Video tutorials and guides. 5. **Designs / Creative Works (`designs.html`)** Portfolio of creative works and designs. 6. **Explore Turkey (`explore.html`)** API powered gallery showcasing Turkish landmarks, images, and descriptions in interactive cards. 7. **Contact Developer (`contact.html`)** Contact form and developer information with links to GitHub, LinkedIn, Instagram, Facebook, Portfolio, and Blog. --- ## Technologies Used - **HTML5** & **CSS3** - **JavaScript (ES6+)** - **Bootstrap 5** (responsive grid & components) - **Tailwind CSS** (utility-first styling) - **FontAwesome** (icons) - **Fetch API** (Explore Turkey dynamic content) - **Netlify** (deployment) --- ## Installation 1. Clone the repository: ```bash git clone https://github.com/EnverHakimoglu/Turkipedia.git 

Navigate to the project folder: cd Turkipedia 

Open index.html in your preferred browser.

Usage

Browse the website to explore Turkish culture and creative content.

Submit messages through the Contact Developer page.

Use the Explore Turkey section to see dynamic destination cards (API powered).

Developer Contact

Enver Hakimoglu

Phone: 01552162595

Email: EnverHakimdaroglu@gmail.com

GitHub: https://github.com/EnverHakimoglu

LinkedIn: https://eg.linkedin.com/in/enver-hakimdaro%C4%9Flu-b2907a376

Instagram: https://www.instagram.com/enverhakimdar

Facebook: https://www.facebook.com/share/176A7ac58y/

Portfolio: https://enverhakimdarogluportfolio1.netlify.app/

Blog: https://enverblog.netlify.app/

License

This project is free to use and modify for personal and educational purposes.

🎁 Note: This project is created as a professional showcase and gift to my friend Sökmenoglu to demonstrate a high-quality, fully functional web platform.