/* =======================================
   Turkipedia Custom JS
   Author: Enver Hakimoglu
   Handles interactions + API fetch
======================================= */

/* -----------------------------
   Smooth Scroll for Anchor Links
----------------------------- */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});

/* -----------------------------
   Explore Turkey API Fetch
----------------------------- */
const exploreCards = document.getElementById('explore-cards');

async function fetchDestinations() {
  try {
    // Example API endpoint (replace with real endpoint)
    const response = await fetch('https://api.example.com/turkey-destinations');
    if (!response.ok) throw new Error('Network response was not ok');

    const data = await response.json();

    if (!data || data.length === 0) {
      exploreCards.innerHTML = '<p class="text-center text-gray-500">No destinations available at the moment.</p>';
      return;
    }

    // Clear existing cards
    exploreCards.innerHTML = '';

    data.forEach(place => {
      const col = document.createElement('div');
      col.classList.add('col-md-4', 'mb-4');

      col.innerHTML = `
        <div class="card hover-scale shadow-lg bg-white rounded-lg overflow-hidden">
          <img src="${place.image}" class="card-img-top" alt="${place.name}">
          <div class="card-body">
            <h5 class="card-title font-bold text-xl mb-1">${place.name}</h5>
            <p class="card-text text-gray-700">${place.description}</p>
          </div>
        </div>
      `;

      exploreCards.appendChild(col);
    });

  } catch (error) {
    console.error('Error fetching destinations:', error);
    exploreCards.innerHTML = '<p class="text-center text-red-500">Failed to load destinations. Please try again later.</p>';
  }
}

// Call the function only if the Explore page exists
if (exploreCards) {
  fetchDestinations();
}

/* -----------------------------
   Optional: Lazy Loading Images
----------------------------- */
document.addEventListener("DOMContentLoaded", function() {
  const lazyImages = document.querySelectorAll("img");
  lazyImages.forEach(img => {
    img.loading = "lazy";
  });
});

/* -----------------------------
   Optional: Navbar Shadow on Scroll
----------------------------- */
const navbar = document.querySelector('.navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    navbar.classList.add('shadow-lg', 'bg-white');
  } else {
    navbar.classList.remove('shadow-lg', 'bg-white');
  }
});

/* -----------------------------
   Optional: Form Submission Handler (Contact)
----------------------------- */
const contactForm = document.querySelector('form');
if(contactForm){
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thank you! Your message has been sent.');
    contactForm.reset();
  });
}