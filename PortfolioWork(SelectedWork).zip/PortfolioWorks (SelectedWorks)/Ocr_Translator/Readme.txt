# ImageTextTranslator

A professional project for extracting text from images (OCR) and translating it to any desired language.

## Project Structure

ImageTextTranslator/ ├── data/                 # Test images │   └── example.jpg ├── scripts/ │   ├── ocr_extractor.py  # Extract text from images │   ├── translator.py     # Translate text to target language │   └── app.py            # Streamlit user interface ├── requirements.txt └── README.md

## Project Overview

ImageTextTranslator allows users to:
- Upload images containing text.
- Extract text from the images using OCR (EasyOCR).
- Translate the extracted text into multiple languages using Google Translate API.
- Display both the extracted and translated text in a user-friendly interface.

## Features

- Multi-language OCR support (English, Arabic, etc.).
- Translation to multiple languages (English, French, Spanish, Arabic, German, Chinese).
- Streamlit web interface for easy usage.
- Modular code structure for easy extension and maintenance.

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd ImageTextTranslator

2. Install required packages:



pip install -r requirements.txt

3. Run the Streamlit app:



streamlit run scripts/app.py

Usage

Upload an image (JPG, PNG).

View the extracted text from the image.

Select the target language.

View the translated text.


License

This project is open-source and free to use.