# EnglishHub EnglishHub is a modern web application designed for English learners, readers, and language enthusiasts. It provides access to English stories, dictionary meanings, and a smart translator, all in one sleek and interactive platform. --- ## Table of Contents 1. [Project Overview](#project-overview) 2. [Features](#features) 3. [Technologies Used](#technologies-used) 4. [File Structure](#file-structure) 5. [How to Run](#how-to-run) 6. [Developer](#developer) 7. [Contact](#contact) --- ## Project Overview EnglishHub is built with the goal of helping users improve their English skills. The platform includes: - A **Hero section** introducing the project. - A **Stories & Novels section** for reading English literature. - A **Dictionary** to search for word meanings. - A **Smart Translator** that translates English text to any supported language. The design emphasizes simplicity, usability, and responsiveness with a modern aesthetic using **Bootstrap 5**, **Tailwind CSS**, and **FontAwesome**. --- ## Features - **Hero Section**: Clean landing page with project overview. - **Stories & Novels**: Browse, read, and enjoy English literature. - **Dictionary**: Search words and view their meanings, parts of speech, and definitions. - **Smart Translator**: Translate English text to multiple languages in real-time. - **Responsive Design**: Works on mobile, tablet, and desktop devices. - **Interactive UI**: Smooth interactions and modern card-based layouts. --- ## Technologies Used - **HTML5 & CSS3** - **JavaScript (ES6+)** - **Bootstrap 5 (CDN)** - **Tailwind CSS (CDN)** - **FontAwesome Icons (CDN)** - **LibreTranslate API** for translations - **Free Dictionary API** for dictionary definitions --- ## File Structure 

EnglishHub/ │ ├── index.html ← Hero section + About project ├── stories.html ← English stories & novels ├── dictionary.html ← Word meanings & search ├── translator.html ← Smart translator ├── about.html ← About project & developer ├── contact.html ← Contact page │ ├── css/ │ └── style.css ← Custom styles │ ├── js/ │ ├── main.js ← General scripts │ ├── stories.js ← Story listing & reading │ ├── dictionary.js ← Dictionary API integration │ └── translator.js ← Translator API integration │ ├── assets/ │ ├── images/ ← Backgrounds, illustrations │ └── icons/ ← Extra icons │ └── README.md ← Project documentation

--- ## How to Run 1. Clone the repository: ```bash git clone <your-repo-url> 

Open index.html in your preferred browser.

Make sure you have an internet connection to load CDN resources and APIs.

Start exploring the sections: Stories, Dictionary, and Translator.

Developer

Shihab UzBashi Oglu (EnverHakimdar)

GitHub: https://github.com/EnverHakimoglu

Portfolio: https://shihabubashiportfolio.netlify.app/

LinkedIn: https://eg.linkedin.com/in/enver-hakimdaro%C4%9Flu-b2907a376

Contact

For any questions or support, you can reach out via:

Email: EnverHakimdaroglu@gmail.com

Phone: 01552162595

Instagram: https://www.instagram.com/enverhakimdar

Facebook: https://www.facebook.com/share/176A7ac58y/

EnglishHub is a project developed with love to enhance English learning and reading experiences for users worldwide.