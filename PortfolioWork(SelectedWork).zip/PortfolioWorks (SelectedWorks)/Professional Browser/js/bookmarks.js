/* ===========================
   Bookmarks Management - bookmarks.js
=========================== */

const bookmarksContainer = document.getElementById('bookmarksContainer');
const addBookmarkBtn = document.getElementById('addBookmarkBtn');

let bookmarks = [];

// Load saved bookmarks from LocalStorage
if (localStorage.getItem('browserBookmarks')) {
  bookmarks = JSON.parse(localStorage.getItem('browserBookmarks'));
  renderBookmarks();
}

// Function to render all bookmarks
function renderBookmarks() {
  if (!bookmarksContainer) return;

  bookmarksContainer.innerHTML = '';
  bookmarks.forEach((bookmark, index) => {
    const bookmarkEl = document.createElement('div');
    bookmarkEl.className = 'card mb-3 p-3 flex justify-between items-center fadeInUp';
    bookmarkEl.innerHTML = `
      <div>
        <h3>${bookmark.title}</h3>
        <p>${bookmark.url}</p>
      </div>
      <div>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteBookmark(${index})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `;
    bookmarkEl.addEventListener('click', () => openBookmark(bookmark.url));
    bookmarksContainer.appendChild(bookmarkEl);
  });
}

// Add a new bookmark
if (addBookmarkBtn) {
  addBookmarkBtn.addEventListener('click', () => {
    const title = prompt('Enter Bookmark Title:');
    const url = prompt('Enter Bookmark URL:');
    if (title && url) {
      bookmarks.push({ title, url });
      saveBookmarks();
      renderBookmarks();
    }
  });
}

// Delete a bookmark
function deleteBookmark(index) {
  bookmarks.splice(index, 1);
  saveBookmarks();
  renderBookmarks();
}

// Open bookmark in a new tab/window
function openBookmark(url) {
  window.open(url, '_blank');
}

// Save bookmarks to LocalStorage
function saveBookmarks() {
  localStorage.setItem('browserBookmarks', JSON.stringify(bookmarks));
}