/* ===========================
   General Script - script.js
=========================== */

/* ---------------------------
   Dark / Light Mode Toggle
--------------------------- */
const darkModeToggle = document.getElementById('darkModeToggle');

if (darkModeToggle) {
  // Load previous preference from LocalStorage
  if (localStorage.getItem('darkMode') === 'enabled') {
    document.body.classList.add('dark-mode');
    darkModeToggle.checked = true;
  }

  darkModeToggle.addEventListener('change', () => {
    document.body.classList.toggle('dark-mode');
    if (document.body.classList.contains('dark-mode')) {
      localStorage.setItem('darkMode', 'enabled');
    } else {
      localStorage.setItem('darkMode', 'disabled');
    }
  });
}

/* ---------------------------
   Search Bar Functionality
--------------------------- */
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');

if (searchButton && searchInput) {
  searchButton.addEventListener('click', () => {
    const query = searchInput.value.trim();
    if (query) {
      alert(`You searched for: "${query}"`);
      // Future: integrate with Tabs or explore.html to show results
    }
  });

  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      searchButton.click();
    }
  });
}

/* ---------------------------
   Toggle Sections / Tabs
--------------------------- */
function showSection(sectionId) {
  const sections = document.querySelectorAll('.section');
  sections.forEach(sec => {
    sec.style.display = 'none';
  });

  const target = document.getElementById(sectionId);
  if (target) {
    target.style.display = 'block';
  }
}

/* ---------------------------
   General Utility Functions
--------------------------- */

// Smooth scroll to an element
function scrollToElement(selector) {
  const el = document.querySelector(selector);
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

// Example: Toggle visibility for an element
function toggleVisibility(selector) {
  const el = document.querySelector(selector);
  if (el) el.classList.toggle('hidden');
}

/* ---------------------------
   Initialize Scripts
--------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  console.log('ProfessionalBrowser: General scripts loaded.');
});