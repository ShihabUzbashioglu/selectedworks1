/* ===========================
   Settings Management - settings.js
=========================== */

const darkModeToggle = document.getElementById('darkModeToggle');
const themeSelector = document.getElementById('themeSelector');

let settings = {
  darkMode: false,
  themeColor: 'default'
};

// Load saved settings from LocalStorage
if (localStorage.getItem('browserSettings')) {
  settings = JSON.parse(localStorage.getItem('browserSettings'));
  applySettings();
}

// Apply settings to page
function applySettings() {
  // Dark Mode
  if (settings.darkMode) {
    document.body.classList.add('dark-mode');
    if (darkModeToggle) darkModeToggle.checked = true;
  } else {
    document.body.classList.remove('dark-mode');
    if (darkModeToggle) darkModeToggle.checked = false;
  }

  // Theme Color
  if (themeSelector) {
    themeSelector.value = settings.themeColor;
    document.documentElement.style.setProperty('--theme-color', settings.themeColor);
  }
}

// Dark Mode Toggle
if (darkModeToggle) {
  darkModeToggle.addEventListener('change', () => {
    settings.darkMode = darkModeToggle.checked;
    applySettings();
    saveSettings();
  });
}

// Theme Selector
if (themeSelector) {
  themeSelector.addEventListener('change', () => {
    settings.themeColor = themeSelector.value;
    applySettings();
    saveSettings();
  });
}

// Save settings to LocalStorage
function saveSettings() {
  localStorage.setItem('browserSettings', JSON.stringify(settings));
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  applySettings();
  console.log('ProfessionalBrowser: Settings loaded.');
});