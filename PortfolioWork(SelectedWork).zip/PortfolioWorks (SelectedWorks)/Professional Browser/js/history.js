/* ===========================
   History Management - history.js
=========================== */

const historyContainer = document.getElementById('historyContainer');

let historyItems = [];

// Load saved history from LocalStorage
if (localStorage.getItem('browserHistory')) {
  historyItems = JSON.parse(localStorage.getItem('browserHistory'));
  renderHistory();
}

// Function to render all history items
function renderHistory() {
  if (!historyContainer) return;

  historyContainer.innerHTML = '';
  historyItems.forEach((item, index) => {
    const historyEl = document.createElement('div');
    historyEl.className = 'card mb-3 p-3 flex justify-between items-center fadeInUp';
    historyEl.innerHTML = `
      <div>
        <h3>${item.title}</h3>
        <p>${item.url}</p>
        <small>${item.date}</small>
      </div>
      <div>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteHistory(${index})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `;
    historyEl.addEventListener('click', () => openHistory(item.url));
    historyContainer.appendChild(historyEl);
  });
}

// Add a new history item
function addHistory(title, url) {
  const date = new Date().toLocaleString();
  historyItems.push({ title, url, date });
  saveHistory();
  renderHistory();
}

// Delete a history item
function deleteHistory(index) {
  historyItems.splice(index, 1);
  saveHistory();
  renderHistory();
}

// Open history item in a new tab/window
function openHistory(url) {
  window.open(url, '_blank');
}

// Save history to LocalStorage
function saveHistory() {
  localStorage.setItem('browserHistory', JSON.stringify(historyItems));
}

// Optional: Example to add current page to history
document.addEventListener('DOMContentLoaded', () => {
  const currentTitle = document.title;
  const currentURL = window.location.href;
  addHistory(currentTitle, currentURL);
});