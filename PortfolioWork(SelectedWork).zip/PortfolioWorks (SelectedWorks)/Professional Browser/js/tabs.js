/* ===========================
   Tabs Management - tabs.js
=========================== */

const tabsContainer = document.getElementById('tabsContainer');
const newTabButton = document.getElementById('newTabButton');

let tabs = [];

// Load saved tabs from LocalStorage
if (localStorage.getItem('browserTabs')) {
  tabs = JSON.parse(localStorage.getItem('browserTabs'));
  renderTabs();
}

// Function to render all tabs
function renderTabs() {
  if (!tabsContainer) return;

  tabsContainer.innerHTML = '';
  tabs.forEach((tab, index) => {
    const tabEl = document.createElement('div');
    tabEl.className = 'card mb-3 p-3 flex justify-between items-center fadeInUp';
    tabEl.innerHTML = `
      <div>
        <h3>${tab.title}</h3>
        <p>${tab.url}</p>
      </div>
      <div>
        <button class="btn btn-sm btn-outline-danger" onclick="closeTab(${index})">
          <i class="fas fa-times"></i>
        </button>
      </div>
    `;
    tabEl.addEventListener('click', () => switchTab(index));
    tabsContainer.appendChild(tabEl);
  });
}

// Add a new tab
if (newTabButton) {
  newTabButton.addEventListener('click', () => {
    const title = prompt('Enter Tab Title:');
    const url = prompt('Enter Tab URL:');
    if (title && url) {
      tabs.push({ title, url });
      saveTabs();
      renderTabs();
    }
  });
}

// Close a tab
function closeTab(index) {
  tabs.splice(index, 1);
  saveTabs();
  renderTabs();
}

// Switch to a tab
function switchTab(index) {
  const tab = tabs[index];
  if (!tab) return;
  alert(`Switched to tab:\n${tab.title}\n${tab.url}`);
  // Future: render the tab content dynamically
}

// Save tabs to LocalStorage
function saveTabs() {
  localStorage.setItem('browserTabs', JSON.stringify(tabs));
}