/* ===========================
   Service Worker - service-worker.js
=========================== */

const CACHE_NAME = 'professional-browser-v1';
const OFFLINE_URL = 'offline.html'; // صفحة Offline fallback
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/tabs.html',
  '/bookmarks.html',
  '/history.html',
  '/settings.html',
  '/css/style.css',
  '/js/script.js',
  '/js/tabs.js',
  '/js/bookmarks.js',
  '/js/history.js',
  '/js/settings.js',
  '/assets/images/logo.png', // مثال
  '/assets/icons/favicon.ico',
  OFFLINE_URL
];

// Install Service Worker & Cache Assets
self.addEventListener('install', event => {
  console.log('[ServiceWorker] Install');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[ServiceWorker] Caching app shell');
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Activate Service Worker & Clean old caches
self.addEventListener('activate', event => {
  console.log('[ServiceWorker] Activate');
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.map(key => {
          if (key !== CACHE_NAME) {
            console.log('[ServiceWorker] Removing old cache:', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch: Serve cached content when offline
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request).then(response => {
        return response || caches.match(OFFLINE_URL);
      });
    })
  );
});